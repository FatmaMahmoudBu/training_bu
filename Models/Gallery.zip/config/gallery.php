<?php 
                        return [
'command' => [
'id' => '24',
'name' => 'Gallery',
'options' => 'name:string::true',
'command' => 'laraflat:admin_model',
'created_at' => '2022-09-28 01:41:11',
'updated_at' => '2022-09-28 01:41:11',
],
];
