<?php 

return [
    'gallery' => 'gallery',
    'name' => '',
    'edit' => '',
    'show' => '',
    'delete' => '',
];