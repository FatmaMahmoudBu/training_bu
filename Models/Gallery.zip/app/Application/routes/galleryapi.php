<?php
            #Gallery
            Route::get('gallery/getById/{id}/{lang?}', 'GalleryApi@getById');
            Route::get('gallery/delete/{id}', 'GalleryApi@delete');
            Route::post('gallery/add', 'GalleryApi@add');
            Route::post('gallery/update/{id}', 'GalleryApi@update');
            Route::get('gallery/{limit?}/{offset?}/{lang?}', 'GalleryApi@index');