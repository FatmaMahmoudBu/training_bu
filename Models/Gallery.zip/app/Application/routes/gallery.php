<?php
                #### Gallery control
                Route::get('gallery', 'GalleryController@index');
                Route::get('gallery/item/{id?}', 'GalleryController@show');
                Route::post('gallery/item', 'GalleryController@store');
                Route::post('gallery/item/{id}', 'GalleryController@update');
                Route::get('gallery/{id}/delete', 'GalleryController@destroy');
                Route::get('gallery/{id}/view', 'GalleryController@getById');