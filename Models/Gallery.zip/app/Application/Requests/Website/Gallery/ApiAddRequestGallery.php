<?php

namespace App\Application\Requests\Website\Gallery;


class ApiAddRequestGallery
{
    public function rules()
    {
        return [
            "name" => "",
			
        ];
    }
}
