<a href="{{ url('gallery/item/'.$id) }}" class="btn btn-info">
    <i class="fa fa-edit"></i>
</a>