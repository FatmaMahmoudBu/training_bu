<a href="{{ url('gallery/'.$id.'/view') }}" class="btn btn-warning">
    <i class="fa fa-eye"></i>
</a>